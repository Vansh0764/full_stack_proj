const express = require("express");
const path = require("path");
const User = require('./models/usermessage');
const Preference = require("./models/preference");

const mongoose = require("mongoose");

mongoose.set("strictQuery" , true);
mongoose.connect("mongodb+srv://vansh:12345@cluster0.qdavdt9.mongodb.net/?retryWrites=true&w=majority")
    .then( () => console.log("Connection Successful!"))
    .catch((err) => console.log(err))

    
const app = express();

const cors = require("cors");
app.use(cors())

const bodyParser = require('body-parser')
app.use(bodyParser.json())
app.use(bodyParser.urlencoded({extended: true}))

const port = process.env.PORT || 5000;

app.use(express.json()); 
app.use(express.urlencoded({extended : false}))

const staticPath = path.join(__dirname , "../public");  

app.use(express.static(staticPath));


// contact
app.post("/contact", (req,res) => {
    const newData = new User({
        _id: mongoose.Types.ObjectId(),
        name: req.body.name,
        email: req.body.email,
        phone: req.body.phone,
        address: req.body.address
    })
    newData.save()
        .then(result => res.status(201).json({ message: "Contact details submitted!", details: result }))
        .catch(err => res.status(500).json({ message: "Server error", error: err }))
});



// preference
app.post("/preference" , (req, res) => {
    const newData = new Preference({
        _id: mongoose.Types.ObjectId(),
        gender: req.body.gender,
        religion: req.body.religion,
        age: req.body.age,
        city: req.body.city,
        occupation: req.body.occupation
    })
    newData.save()
        .then(result => res.status(201).json({ message: "Preference details submitted!", details: result }))
        .catch(err => res.status(500).json({ message: "Server error", error: err }))
})



app.listen(port , () => {
    console.log(`App started at port ${port}`);
});