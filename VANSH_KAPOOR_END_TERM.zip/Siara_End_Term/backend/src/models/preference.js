const mongoose = require("mongoose");

const prefSchema = {
    _id: mongoose.Schema.Types.ObjectId,
    gender : {
        type : String,
        required : true
    },
    religion : {
        type : String,
        required : true
    },
    age : {
        type : Number,
        required : true
    },
    city : {
        type : String,
        required : true
    },
    occupation : {
        type : String,
        required : true
    }
}

module.exports = mongoose.model('Preference', prefSchema);