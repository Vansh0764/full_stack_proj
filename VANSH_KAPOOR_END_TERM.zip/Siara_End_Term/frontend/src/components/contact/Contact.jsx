import React from 'react'
import axios from 'axios'
import './Contact.css'

const Contact = () => {

    const postDetails = (e) => {
        e.preventDefault()

        const postData = {
            name: document.getElementById("contactName").value,
            email: document.getElementById("contactEmail").value,
            phone: document.getElementById("contactPhone").value,
            address: document.getElementById("contactAddress").value,
        }
        axios.post('http://localhost:5000/contact', postData)
            .then(result => {
                console.log(result)
            })
            .catch(err => console.log(err))
    }

  return (
    <div className="contact-section">
        <h1 className="text-center main-heading" style={{color: "orange"}}>Wanna Contact Us</h1>

        <br />
        
        <form>
            <div className="form-group">
                <label htmlFor="contactName">Name: </label>
                <input type="text" className="form-control input1" id="contactName" placeholder="Enter the name" name="name" />
            </div>

            <div className="form-group">
                <label htmlFor="contactEmail">E-mail Address: </label>
                <input type="email" className="form-control input1" id="contactEmail" placeholder="Enter the email" name="email" />
            </div>

            <div className="form-group">
                <label htmlFor="contactPass">Contact Number: </label>
                <input type="number" className="form-control input1" id="contactPhone" placeholder="Enter the contact number" name="phone" />
            </div>

            <div className="form-group">
                <label htmlFor="contactAddress">Address: </label>
                <input type="text" className="form-control input1" id="contactAddress" placeholder="Enter the address" name="address" />
            </div>

            <br />
            <br />
            
            <button className="btn btn-danger" onClick={postDetails}><b>DONE</b></button>
        </form>
    </div>
  )
}

export default Contact;