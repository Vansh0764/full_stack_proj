import React from 'react'
import './About.css'

const About = () => {
  return (

    <div className='about-us-container'>
      <div className="about-us-left">
        <img src="images/example1.jfif" alt="image" />
      </div>

      <div className="about-us-right">
        <h1 className="text-center main-heading">!!! WHAT'S SIARA !!!</h1>
        <p style={{color: "red"}}>
          Welcome to Siara , where you can get the one and the only soulmate of your life.
          The place where you can check your compatibility and find your ideal match.
          You can be in touch with various people and find your true love.
          A place where your manifestations can come true.
        </p>
        <p style={{color: "green"}}>
          A place thats fills the air around you with love.Love is an emotion that keeps people bonded and committed to one another.
        </p>
        <p style={{color: "black"}}>
          Siara always say ,
        </p>
        <p style={{color: "orchid"}}>
          I LOVE YOU FOR THE EMOTIONS ,
        </p>
        <p style={{color: "purple"}}>
          I NEVER KNEW I HAD,
        </p>
        <p style={{color: "orchid"}}>
          I THANK YOU FOR COMING IN MY LIFE
        </p>
        <p style={{color: "purple"}}>
          WHEN I NEEDED SOMEONE THE MOST..
        </p>
      </div>
    </div>
  )
}

export default About;