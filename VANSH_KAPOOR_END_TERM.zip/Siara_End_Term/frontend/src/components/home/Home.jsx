import React from 'react'
import { Link } from 'react-router-dom'
import './Home.css'

const Home = () => {
  return (
    <>
    
    <br/>

    <div className='home-container'>
      <div className="home-left">
        <img src="images/example2.jfif" alt="image" />
      </div>

      <div className="home-right">
        <h1 style={{color: "IndianRed" , width: "80%"}}>Dhoondh lo apna pyaar,
          Just like our favourite kiara and siddharth
        </h1>
        <p> Your Ideal One is waiting to meet you! </p>
        <Link to={'/about'}>
          <button className="home-about-us"><b>Know Siara</b></button>
        </Link>
      </div>
    </div>

    </>
  )
}


export default Home;