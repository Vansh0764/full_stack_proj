import React from 'react'
import './Navbar.css'

import { Link } from "react-router-dom";

const Navbar = () => {
  return (

    <nav className="navbar">
        <audio src='../../audio/music.mp3' type="audio/mpeg" autoPlay
            //style={{ display: "none" }}
        />

        <h2 className='site-name'>Siara</h2>

        <div className="collapse navbar-collapse" id="navbarSupportedContent">
            <ul className="navbar-nav ms-auto">
                <li className="nav-item active">
                    <Link to={'/'}> Home </Link>
                </li>
                <li className="nav-item">
                    <Link to={'/preference'}> Preferences </Link>
                </li>
                <li className="nav-item">
                    <Link to={'/contact'}> Contact </Link>
                </li>
                <li className="nav-item">
                    <Link to={'/about'}> About Us </Link>
                </li>
            </ul>
        </div>
    </nav>

  )
}

export default Navbar;