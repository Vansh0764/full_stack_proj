import React from 'react'
import axios from 'axios'
import './Preference.css'

const Preference = () => {

    const postDetails = (e) => {
        e.preventDefault()

        const postData = {
            gender: document.getElementById("lookingForGender").value,
            religion: document.getElementById("lookingForReligion").value,
            age: document.getElementById("lookingForMT").value,
            city: document.getElementById("lookingForCity").value,
            occupation: document.getElementById("lookingForOcc").value
        }
        axios.post('http://localhost:5000/preference', postData)
            .then(result => {
                console.log(result)
                alert(result.data.message)
            })
            .catch(err => console.log(err))
    }


  return (

    <div className='looking-for'>
        <h1 className="text-center main-heading" style={{color: "MediumSeaGreen"}}>What your ideal match look like?</h1>
        <p className="text-center sub-heading" style={{color: "blue"}}>The person looks like !!</p>

        <br />

        <form>
            <div className="form-group">
                <label htmlFor="lookingForGender">Looking For: </label>
                <input type="text" className="form-control input1" id="lookingForGender" placeholder="Him/Her" name="gender" />
            </div>

            <div className="form-group">
                <label htmlFor="lookingForReligion">Religion: </label>
                <input type="text" className="form-control input1" id="lookingForReligion" placeholder="Enter any religion" name="religion" />
            </div>

            <div className="form-group">
                <label htmlFor="lookingForMT">Age: </label>
                <input type="text" className="form-control input1" id="lookingForMT" placeholder="Enter the age" name="age" />
            </div>

            <div className="form-group">
                <label htmlFor="lookingForCity">City: </label>
                <input type="text" className="form-control input1" id="lookingForCity" placeholder="Enter the city of your choice" name="city" />
            </div>

            <div className="form-group">
                <label htmlFor="lookingForOcc">Occupation: </label>
                <input type="text" className="form-control input1" id="lookingForOcc" placeholder="Enter any Occupation" name="occupation" />
            </div>

            <br /> <br />

            <button className="btn btn-danger" onClick={postDetails}>
                <b>DONE</b>
            </button>
        </form>
    </div>

  )
}

export default Preference;