import Preference from './components/preference/Preference';
import Navbar from './components/navbar/Navbar';
import About from './components/about/About';
import Contact from './components/contact/Contact';
import Home from './components/home/Home';

import './App.css';

import { BrowserRouter, Routes, Route } from "react-router-dom";


const App = () => {
  return (
    <div className="App">
      
      
      <BrowserRouter>
        <Navbar />

        <Routes>

          <Route path="/" element={<Home />}> </Route>
          <Route path="/preference" element={<Preference />}> </Route>
          <Route path="/about" element={<About />}> </Route>
          <Route path="/contact" element={<Contact />}> </Route>

        </Routes>
      
      </BrowserRouter>
    
    </div>
  );
}

export default App;